"""
Route computation API endpoints.

Bug 4 fix: uses explicit use_custom_weights flag instead of fragile float comparison.
Bug 5 fix: /compare runs all 4 A* searches concurrently via asyncio.gather.
"""

import asyncio
from datetime import datetime, timezone, timedelta

from fastapi import APIRouter, HTTPException

from models import RouteRequest, RouteResponse, CompareRoutesResponse, RouteProfile
from routing import find_route, get_profile_weights

router = APIRouter()
BANGALORE_TZ = timezone(timedelta(hours=5, minutes=30))


def _parse_hour(departure_time: str | None) -> int | None:
    """Parse ISO-8601 input and return the Bangalore local hour."""
    if not departure_time:
        return None

    try:
        normalized = departure_time.replace("Z", "+00:00")
        parsed = datetime.fromisoformat(normalized)
    except ValueError as exc:
        raise HTTPException(
            status_code=400,
            detail="departure_time must be an ISO-8601 datetime string.",
        ) from exc

    if parsed.tzinfo is None:
        return parsed.hour
    return parsed.astimezone(BANGALORE_TZ).hour


@router.post("", response_model=RouteResponse)
async def compute_route(request: RouteRequest):
    """
    Compute a health-and-safety-aware route between two points.

    The route minimizes: C_e = α·T_e + β·∫AQI(t)dt + γ·R_e

    - Set use_custom_weights=true to use slider values directly
    - Set use_custom_weights=false (default) to use profile presets
    """
    if request.use_custom_weights:
        alpha, beta, gamma = request.alpha, request.beta, request.gamma
    else:
        alpha, beta, gamma = get_profile_weights(request.profile)

    hour = _parse_hour(request.departure_time)

    route = await find_route(
        origin_lat=request.origin.lat,
        origin_lon=request.origin.lon,
        dest_lat=request.destination.lat,
        dest_lon=request.destination.lon,
        alpha=alpha,
        beta=beta,
        gamma=gamma,
        profile=request.profile,
        hour=hour,
    )

    if not route:
        # Fix R1: distinguish between "no road near point" and "no path found"
        # so users get actionable feedback instead of a generic 404
        from spatial_queries import snap_to_nearest_node
        origin_node = await snap_to_nearest_node(
            request.origin.lat, request.origin.lon
        )
        dest_node = await snap_to_nearest_node(
            request.destination.lat, request.destination.lon
        )
        if not origin_node:
            raise HTTPException(
                status_code=422,
                detail="No road found within 500m of the origin point. "
                       "Try clicking on or near a road.",
            )
        if not dest_node:
            raise HTTPException(
                status_code=422,
                detail="No road found within 500m of the destination point. "
                       "Try clicking on or near a road.",
            )
        raise HTTPException(
            status_code=404,
            detail="No route found between these two points. "
                   "The locations may be disconnected in the road network.",
        )

    return route


@router.get("/compare", response_model=CompareRoutesResponse)
async def compare_routes(
    origin_lat: float,
    origin_lon: float,
    dest_lat: float,
    dest_lon: float,
    departure_time: str | None = None,
):
    """
    Compare routes across all profiles (fastest, safest, healthiest, balanced).
    Bug 5 fix: runs all 4 A* searches concurrently instead of sequentially.
    """
    hour = _parse_hour(departure_time)

    results = await asyncio.gather(*[
        find_route(
            origin_lat=origin_lat,
            origin_lon=origin_lon,
            dest_lat=dest_lat,
            dest_lon=dest_lon,
            alpha=a, beta=b, gamma=g,
            profile=p,
            hour=hour,
        )
        for p in RouteProfile
        for a, b, g in [get_profile_weights(p)]
    ], return_exceptions=True)

    routes = [r for r in results if r and not isinstance(r, Exception)]

    if not routes:
        raise HTTPException(
            status_code=404,
            detail="No routes found between the given points.",
        )

    return CompareRoutesResponse(routes=routes)
