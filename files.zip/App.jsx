import { useState, useCallback, useEffect, useRef, memo } from 'react';
import Sidebar from './components/Sidebar';
import MapView from './components/MapView';
import LandingPage from './components/LandingPage';
import GreenScore, { SESSION_ID } from './components/GreenScore';
import PWAInstallPrompt from './components/PWAInstallPrompt';
import { decodeURLToRoute, encodeRouteToURL, buildShareURL } from './utils/shareURL';
import './index.css';
import 'leaflet/dist/leaflet.css';

const API_BASE = '/api';

const PRESET_WEIGHTS = {
    fastest:    { alpha: 1.0, beta: 0.0, gamma: 0.0 },
    safest:     { alpha: 0.2, beta: 0.1, gamma: 0.7 },
    healthiest: { alpha: 0.1, beta: 0.7, gamma: 0.2 },
    balanced:   { alpha: 0.4, beta: 0.3, gamma: 0.3 },
};

// ── Nav bar (extracted for reuse across views) ─────────────────
function useIST() {
    const [time, setTime] = useState(() =>
        new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata', hour12: false })
    );
    useEffect(() => {
        const tick = setInterval(() =>
            setTime(new Date().toLocaleTimeString('en-IN', {
                hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata', hour12: false
            })), 30_000);
        return () => clearInterval(tick);
    }, []);
    return time;
}

const NavBar = memo(function NavBar({ view, setView, handleShowAQI, isOffline, incidentCount }) {
    const istTime = useIST();
    return (
        <div className="nav-bar">
            {/* Brand */}
            <div className="nav-brand">
                <div className="nav-logo">
                    <div className="nav-hex" />
                    <span className="nav-wordmark">SafeMAPS</span>
                </div>
                <span className="nav-system-label">BLR HEALTH ROUTING · v0.5</span>
            </div>

            {/* Tabs */}
            <div className="nav-tabs">
                {[
                    { id: 'dashboard',   label: 'Dashboard',   icon: '▣' },
                    { id: 'heatmaps',    label: 'Heatmaps',    icon: '◈' },
                    { id: 'greenscore',  label: 'Green Score', icon: '◆' },
                ].map(tab => (
                    <button
                        key={tab.id}
                        className={`nav-tab ${view === tab.id ? 'active' : ''}`}
                        onClick={() => {
                            if (tab.id === 'heatmaps') handleShowAQI(true);
                            setView(tab.id);
                        }}
                    >
                        <span>{tab.icon}</span>
                        {tab.label}
                    </button>
                ))}
            </div>

            {/* Live readout */}
            <div className="nav-readout">
                <div className={`readout-dot ${isOffline ? 'offline' : ''}`} />
                <div className="readout-item">
                    <span className="readout-value">{isOffline ? 'DEMO' : 'LIVE'}</span>
                    <span className="readout-label">{isOffline ? 'No backend' : 'Data feed'}</span>
                </div>
                {incidentCount > 0 && (
                    <div className="readout-item">
                        <span className="readout-value nav-incident-badge">{incidentCount}</span>
                        <span className="readout-label">incidents</span>
                    </div>
                )}
                <div className="readout-item">
                    <span className="readout-value nav-clock">{istTime}</span>
                    <span className="readout-label">IST</span>
                </div>
            </div>
        </div>
    );
});

export default function App() {
    const [view, setView]                     = useState('landing');
    const [origin, setOrigin]                 = useState({ lat: '', lon: '' });
    const [destination, setDestination]       = useState({ lat: '', lon: '' });
    const [profile, setProfile]               = useState('safest');
    const [weights, setWeights]               = useState({ alpha: 0.20, beta: 0.10, gamma: 0.70 });
    const [departureTime, setDepartureTime]   = useState(null);
    const [routes, setRoutes]                 = useState([]);
    const [selectedRoute, setSelectedRoute]   = useState(null);
    const [loading, setLoading]               = useState(false);
    const [error, setError]                   = useState(null);
    const [showAQI, setShowAQI]               = useState(false);
    const [showBlackspots, setShowBlackspots] = useState(true);
    const [showIncidents, setShowIncidents]   = useState(true);
    const [aqiData, setAqiData]               = useState(null);
    const [loadingAQI, setLoadingAQI]         = useState(false);
    const [blackspotData, setBlackspotData]   = useState(null);
    const [mapBounds, setMapBounds]           = useState(null);
    const [isOffline, setIsOffline]           = useState(false);
    // ── Stable refs so callbacks don't recreate on every state change ─
    const showAQIRef    = useRef(showAQI);
    const fetchAQIRef   = useRef(null);
    const originRef     = useRef(origin);
    const destinationRef = useRef(destination);
    useEffect(() => { showAQIRef.current = showAQI; }, [showAQI]);
    useEffect(() => { originRef.current = origin; }, [origin]);
    useEffect(() => { destinationRef.current = destination; }, [destination]);
    const [bannerDismissed, setBannerDismissed] = useState(false);
    const [shareCopied, setShareCopied]       = useState(false);
    const [incidents, setIncidents]           = useState([]);
    const pendingAutoCompute                  = useRef(false);

    // ── Decode URL params on mount → auto-fill + auto-compute ─────────
    useEffect(() => {
        const decoded = decodeURLToRoute();
        if (decoded) {
            setOrigin(decoded.origin);
            setDestination(decoded.destination);
            handleProfileChange(decoded.profile);
            if (decoded.departureTime) setDepartureTime(decoded.departureTime);
            setView('dashboard');
            pendingAutoCompute.current = true;
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    // ── Auto-compute once view is 'dashboard' and coords are loaded ────
    const autoComputeRan = useRef(false);
    useEffect(() => {
        if (pendingAutoCompute.current && view === 'dashboard' &&
            origin.lat && destination.lat && !autoComputeRan.current) {
            autoComputeRan.current = true;
            pendingAutoCompute.current = false;
            // small delay so map renders first
            setTimeout(() => computeRoute(), 200);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [view, origin.lat, destination.lat]);

    // ── Copy share link to clipboard ──────────────────────────────────
    const handleShare = useCallback(() => {
        if (!origin.lat || !destination.lat) return;
        const url = buildShareURL(origin, destination, profile, departureTime);
        navigator.clipboard.writeText(url).then(() => {
            setShareCopied(true);
            setTimeout(() => setShareCopied(false), 2000);
        }).catch(() => {
            // fallback: select text
            prompt('Copy this link:', url);
        });
    }, [origin, destination, profile, departureTime]);

    useEffect(() => {
        let cancelled = false;
        const checkHealth = async () => {
            try {
                const resp = await fetch(`${API_BASE.replace('/api', '')}/health`, {
                    signal: AbortSignal.timeout(4000),
                });
                const data = await resp.json().catch(() => ({}));
                if (!cancelled) {
                    setIsOffline(!resp.ok || data.database === 'disconnected');
                }
            } catch {
                if (!cancelled) setIsOffline(true);
            }
        };
        checkHealth();
        return () => { cancelled = true; };
    }, []);

    useEffect(() => {
        let cancelled = false;
        const fetchIncidents = async () => {
            try {
                const resp = await fetch(`${API_BASE}/incidents/active?limit=300`);
                if (resp.ok) {
                    const data = await resp.json();
                    if (!cancelled) setIncidents(data);
                }
            } catch (err) { console.warn('Incidents fetch failed:', err.message); }
        };
        fetchIncidents();
        const id = setInterval(fetchIncidents, 10 * 60 * 1000);
        return () => {
            cancelled = true;
            clearInterval(id);
        };
    }, []);

    // Keep fetchAQIRef in sync so handleBoundsChange can call latest version
    const fetchAQI = useCallback(async (bounds) => {
        if (!bounds) return;
        setLoadingAQI(true);
        try {
            const p = new URLSearchParams({
                min_lat: bounds.south, max_lat: bounds.north,
                min_lon: bounds.west,  max_lon: bounds.east,
            });
            const resp = await fetch(`${API_BASE}/aqi/heatmap?${p}`);
            if (resp.ok) setAqiData(await resp.json());
        } catch (err) { console.warn('AQI fetch failed:', err.message); }
        finally { setLoadingAQI(false); }
    }, []);
    // keep fetchAQIRef in sync so handleBoundsChange can call latest version
    useEffect(() => { fetchAQIRef.current = fetchAQI; }, [fetchAQI]);

    // Stable callback — does NOT list showAQI in deps; reads via ref instead.
    // This prevents useMapEvents from getting a new function ref on every
    // showAQI toggle, which was the root cause of React error #310.
    const handleBoundsChange = useCallback((bounds) => {
        setMapBounds(bounds);
        if (showAQIRef.current && fetchAQIRef.current) fetchAQIRef.current(bounds);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);  // intentionally empty — reads mutable refs

    const handleShowAQI = useCallback((val) => {
        setShowAQI(val);
        if (val) fetchAQI(mapBounds);
    }, [mapBounds, fetchAQI]);

    const fetchBlackspots = useCallback(async () => {
        try {
            const p = new URLSearchParams({
                min_lat: 12.85, max_lat: 13.15,
                min_lon: 77.45, max_lon: 77.78,
            });
            const resp = await fetch(`${API_BASE}/safety/blackspots?${p}`);
            if (resp.ok) setBlackspotData(await resp.json());
        } catch (err) { console.warn('Blackspot fetch failed:', err.message); }
    }, []);

    useEffect(() => {
        if (view === 'dashboard') fetchBlackspots();
    }, [view, fetchBlackspots]);

    const isFirstRender = useRef(true);
    useEffect(() => {
        if (isFirstRender.current) { isFirstRender.current = false; return; }
        setRoutes([]); setSelectedRoute(null); setError(null);
    }, [origin.lat, origin.lon, destination.lat, destination.lon, departureTime]);

    const handleProfileChange = useCallback((newProfile) => {
        setProfile(newProfile);
        const preset = PRESET_WEIGHTS[newProfile];
        if (preset) setWeights({ alpha: preset.alpha, beta: preset.beta, gamma: preset.gamma });
    }, []);

    const isCustomWeight = useCallback(() => {
        const preset = PRESET_WEIGHTS[profile];
        if (!preset) return true;
        return (
            Math.abs(weights.alpha - preset.alpha) > 0.01 ||
            Math.abs(weights.beta  - preset.beta)  > 0.01 ||
            Math.abs(weights.gamma - preset.gamma)  > 0.01
        );
    }, [profile, weights]);

    const recordTrip = useCallback(async (route) => {
        if (!route) return;
        const cb = route.cost_breakdown;
        try {
            await fetch(`${API_BASE}/user/trips`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-Session-ID': SESSION_ID },
                body: JSON.stringify({
                    origin_lat: +origin.lat, origin_lon: +origin.lon,
                    dest_lat: +destination.lat, dest_lon: +destination.lon,
                    profile: route.profile,
                    distance_km: cb.distance_km,
                    travel_time_min: cb.travel_time_minutes,
                    avg_aqi: cb.avg_aqi,
                    aqi_exposure_integral: cb.aqi_exposure_cost * 500.0 /
                        Math.max(route.weights_used?.beta ?? 0.3, 0.01),
                    hotspots_passed: cb.accident_hotspots_passed,
                }),
            });
        } catch (err) { console.warn('Trip record failed:', err.message); }
    }, [origin, destination]);

    const computeRoute = useCallback(async () => {
        if (!origin.lat || !origin.lon || !destination.lat || !destination.lon) {
            setError('Enter valid coordinates for both points.');
            return;
        }
        setLoading(true); setError(null);
        try {
            let chosen = null;
            if (isCustomWeight()) {
                const body = {
                    origin: { lat: +origin.lat, lon: +origin.lon },
                    destination: { lat: +destination.lat, lon: +destination.lon },
                    profile,
                    alpha: weights.alpha, beta: weights.beta, gamma: weights.gamma,
                    use_custom_weights: true,
                };
                if (departureTime) body.departure_time = departureTime;
                const resp = await fetch(`${API_BASE}/route`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(body),
                });
                if (!resp.ok) throw new Error((await resp.json()).detail || 'Route failed');
                const route = await resp.json();
                setRoutes([route]); setSelectedRoute(route); chosen = route;
            } else {
                const params = new URLSearchParams({
                    origin_lat: origin.lat, origin_lon: origin.lon,
                    dest_lat: destination.lat, dest_lon: destination.lon,
                });
                if (departureTime) params.set('departure_time', departureTime);
                const resp = await fetch(`${API_BASE}/route/compare?${params}`);
                if (!resp.ok) throw new Error((await resp.json()).detail || 'Route failed');
                const data = await resp.json();
                setRoutes(data.routes);
                const sel = data.routes.find(r => r.profile === profile) || data.routes[0];
                setSelectedRoute(sel); chosen = sel;
            }
            if (chosen) {
                recordTrip(chosen);
                // Encode route to URL for sharing/bookmarking
                encodeRouteToURL(origin, destination, profile, departureTime);
            }
        } catch (err) {
            setError(err.message || 'Route computation failed');
            const mocks = getMockRoutes();
            setRoutes(mocks);
            setSelectedRoute(mocks.find(r => r.profile === profile) || mocks[0]);
        } finally { setLoading(false); }
    }, [origin, destination, profile, weights, departureTime, isCustomWeight, recordTrip]);

    // Stable callback — reads origin/destination via refs to avoid
    // giving useMapEvents a new function ref on every click (React #310).
    const handleMapClick = useCallback((latlng) => {
        const o = originRef.current;
        const d = destinationRef.current;
        if (!o.lat) {
            setOrigin({ lat: latlng.lat.toFixed(6), lon: latlng.lng.toFixed(6) });
        } else if (!d.lat) {
            setDestination({ lat: latlng.lat.toFixed(6), lon: latlng.lng.toFixed(6) });
        } else {
            setOrigin({ lat: latlng.lat.toFixed(6), lon: latlng.lng.toFixed(6) });
            setDestination({ lat: '', lon: '' });
            setRoutes([]); setSelectedRoute(null); setError(null);
        }
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);  // intentionally empty — reads mutable refs

    const swapPoints = useCallback(() => {
        setOrigin(destination); setDestination(origin);
    }, [origin, destination]);

    // ── Load a saved commute (one-tap re-route) ────────────────────
    const handleLoadCommute = useCallback((comOrigin, comDest, comProfile) => {
        setOrigin(comOrigin);
        setDestination(comDest);
        handleProfileChange(comProfile);
        setRoutes([]); setSelectedRoute(null); setError(null);
        setTimeout(() => computeRoute(), 200);
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [handleProfileChange]);

    if (view === 'landing') {
        return <LandingPage onStart={() => setView('dashboard')} />;
    }

    const showBanner = isOffline && !bannerDismissed;

    if (view === 'greenscore') {
        return (
            <div className="app" style={{ flexDirection: 'column' }}>
                {showBanner && (
                    <OfflineBanner onDismiss={() => setBannerDismissed(true)} />
                )}
                <NavBar view={view} setView={setView} handleShowAQI={handleShowAQI} isOffline={isOffline} incidentCount={incidents?.length ?? 0} />
                <div className="main-content gs-page" style={{ marginTop: 0 }}>
                    <GreenScore />
                </div>
            </div>
        );
    }

    return (
        <div className="app" style={{ flexDirection: 'column' }}>
            <PWAInstallPrompt />
            {showBanner && (
                <OfflineBanner onDismiss={() => setBannerDismissed(true)} />
            )}
            <NavBar view={view} setView={setView} handleShowAQI={handleShowAQI} isOffline={isOffline} incidentCount={incidents?.length ?? 0} />
            <div className="main-content">
                <Sidebar
                    origin={origin} destination={destination}
                    setOrigin={setOrigin} setDestination={setDestination}
                    profile={profile} setProfile={handleProfileChange}
                    weights={weights} setWeights={setWeights}
                    departureTime={departureTime} setDepartureTime={setDepartureTime}
                    routes={routes} selectedRoute={selectedRoute}
                    setSelectedRoute={setSelectedRoute}
                    onCompute={computeRoute} onSwap={swapPoints}
                    loading={loading} error={error}
                    onShare={handleShare} shareCopied={shareCopied}
                    onLoadCommute={handleLoadCommute}
                />
                <MapView
                    origin={origin} destination={destination}
                    selectedRoute={selectedRoute} routes={routes}
                    showAQI={showAQI} setShowAQI={handleShowAQI}
                    showBlackspots={showBlackspots} setShowBlackspots={setShowBlackspots}
                    showIncidents={showIncidents} setShowIncidents={setShowIncidents}
                    aqiData={aqiData} blackspotData={blackspotData}
                    loadingAQI={loadingAQI}
                    incidentData={incidents}
                    loading={loading} onMapClick={handleMapClick}
                    onBoundsChange={handleBoundsChange}
                />
            </div>
        </div>
    );
}

const OfflineBanner = memo(function OfflineBanner({ onDismiss }) {
    return (
        <div className="offline-banner" role="alert">
            <span className="offline-banner-icon">⚠</span>
            <span className="offline-banner-text">
                Live data unavailable — showing demo routes.
                Backend may still be starting up.
            </span>
            <button className="offline-banner-dismiss" onClick={onDismiss} aria-label="Dismiss">
                ✕
            </button>
        </div>
    );
});


function getMockRoutes() {
    const base = [
        [77.5946, 12.9716],[77.5980,12.9700],[77.6020,12.9660],
        [77.6060,12.9580],[77.6101,12.9352],[77.6150,12.9300],[77.6230,12.9170],
    ];
    return [
        { route_id:'bal', profile:'balanced',   geometry:{type:'LineString',coordinates:base},                               segments:[], cost_breakdown:{total_cost:12.5,travel_time_minutes:22.3,distance_km:8.7,  avg_aqi:95, max_aqi:145,accident_hotspots_passed:2,travel_time_cost:5,  aqi_exposure_cost:4.2,accident_risk_cost:3.3}, weights_used:{alpha:0.4,beta:0.3,gamma:0.3} },
        { route_id:'fast',profile:'fastest',    geometry:{type:'LineString',coordinates:base.map(([a,b])=>[a+0.006,b+0.002])}, segments:[], cost_breakdown:{total_cost:8.1, travel_time_minutes:18.5,distance_km:7.2,  avg_aqi:130,max_aqi:200,accident_hotspots_passed:5,travel_time_cost:8.1,aqi_exposure_cost:0,  accident_risk_cost:0},   weights_used:{alpha:1,  beta:0,  gamma:0}   },
        { route_id:'safe',profile:'safest',     geometry:{type:'LineString',coordinates:base.map(([a,b])=>[a-0.008,b-0.003])}, segments:[], cost_breakdown:{total_cost:15.2,travel_time_minutes:28.1,distance_km:10.3,avg_aqi:72, max_aqi:100,accident_hotspots_passed:0,travel_time_cost:2.8,aqi_exposure_cost:1.5,accident_risk_cost:10.9},weights_used:{alpha:0.2,beta:0.1,gamma:0.7} },
        { route_id:'hlth',profile:'healthiest', geometry:{type:'LineString',coordinates:base.map(([a,b])=>[a-0.012,b+0.005])}, segments:[], cost_breakdown:{total_cost:14.8,travel_time_minutes:32,  distance_km:11.5,avg_aqi:55, max_aqi:78, accident_hotspots_passed:1,travel_time_cost:1.6,aqi_exposure_cost:11.2,accident_risk_cost:2},  weights_used:{alpha:0.1,beta:0.7,gamma:0.2} },
    ];
}
